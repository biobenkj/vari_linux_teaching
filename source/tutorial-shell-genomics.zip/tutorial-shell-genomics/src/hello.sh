#!/bin/bash

echo "Hi there!"
